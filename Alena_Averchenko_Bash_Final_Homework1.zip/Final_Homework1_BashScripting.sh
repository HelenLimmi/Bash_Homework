#!/bin/bash
#create new file with parse lines
awk -F'"' -v OFS='' '{ for (i=2; i<=NF; i+=2) gsub(",", "", $i) } 1' accounts.csv | 
while IFS=, read -r col1 col2 col3 col4 col5 col6 col7 col8 
do
  col5_new=$col5
  if [[ "$col1" != "id" ]]; then
    #update column name (first letter from name and full surname lowercase)
    unset col5_new
    for n in $col5; do
      if [ -z "$col5_new" ] ; then 
        col5_new=${n^}
      else
        col5_new+=" ${n^}"
      fi
    done
    #update column email (first letter from name and full surname)
    firstLetter=${col5:0:1}
    surname=$(echo $col5 | cut -d' ' -f2)
    col7=${firstLetter,}${surname,,}@abc.com
  fi
  echo "${col1},${col2},${col3},${col4},${col5_new},${col6},${col7},${col8}"
done |

#formating email
awk -F, '{ d=dup[$7]++; email = $7; if (d>0) res=gsub("@",(d "@"),$email); echo res} 1' > accounts_new.csv

