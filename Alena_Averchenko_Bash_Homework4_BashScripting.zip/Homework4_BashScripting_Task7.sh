#!/bin/bash
for FILE in * 
do 
  if [[ -f $FILE ]] ; then
    #print only owner of file
    owner=$(stat -c "%U" $FILE)
    echo "Filename: $FILE, Owner: $owner"
  fi
done

