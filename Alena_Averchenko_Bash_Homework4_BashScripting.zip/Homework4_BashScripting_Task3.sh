#!/bin/bash
for item in $(seq 1 85); do
  #check number in range [30,60]
  if ! [[ $item -ge 30 && $item -le 60 ]] ; then
    #check even number
    if [ $((item % 2)) -eq 0 ] ; then
      echo $item
    fi
  fi
done