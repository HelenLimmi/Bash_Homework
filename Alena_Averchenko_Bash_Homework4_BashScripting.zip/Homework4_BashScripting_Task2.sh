#!/bin/bash
echo {20..-20..4}