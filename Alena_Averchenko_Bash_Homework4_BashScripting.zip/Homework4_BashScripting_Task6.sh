#!/bin/bash
input="/home/devops/Bash/task6/paths"
while read line
do
  #check if it directory or regular file
  if [[ "${line: -1}" = "/" ]] ; then
    mkdir $line
  else
    touch $line
  fi
done < "$input"

