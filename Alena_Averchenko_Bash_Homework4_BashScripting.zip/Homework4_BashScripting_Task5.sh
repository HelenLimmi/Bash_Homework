#!/bin/bash
#get random magic number
magicNumber=$(( $RANDOM % 100 ))
while read inputNum 
do
  #check magic number with input number
  if [ $inputNum -lt $magicNumber ] ; then
    echo "less"
  elif [ $inputNum -gt $magicNumber ] ; then
    echo "grater" 
  elif [ $inputNum -eq $magicNumber ] ; then
    echo "You win!"
    exit
  fi
done