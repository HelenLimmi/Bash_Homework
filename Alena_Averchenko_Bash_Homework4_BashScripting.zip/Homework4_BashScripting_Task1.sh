#!/bin/bash
seq -s " " 10