#!/bin/bash
while read var
do
  #check input “stop” word
  if [ "$var" = "stop" ] ; then
    break
  fi
  echo Hello, $var
done

