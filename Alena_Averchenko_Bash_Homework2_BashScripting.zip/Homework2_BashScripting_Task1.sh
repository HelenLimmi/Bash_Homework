#!/bin/bash

date=$(date)
message="Hello, task2!"
echo "[$date] $message"

