#!/bin/bash

#Install zabbix-agent
dnf install -y https://repo.zabbix.com/zabbix/5.0/rhel/8/x86_64/zabbix-release-5.0-1.el8.noarch.rpm
dnf install -y zabbix-agent

#Configuring file /etc/zabbix/zabbix_agentd.conf
sed -i 's/Server=.*/Server=192.168.0.109/' /etc/zabbix/zabbix_agentd.conf
sed -i 's/ServerActive=.*/ServerActive=192.168.0.109/' /etc/zabbix/zabbix_agentd.conf
sed -i 's/Timeout=.*/Timeout=10/' /etc/zabbix/zabbix_agentd.conf

#Run zabbix-agent
systemctl enable zabbix-agent --now