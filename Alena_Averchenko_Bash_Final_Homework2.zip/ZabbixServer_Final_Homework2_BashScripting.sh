#!/bin/bash
#---Set timezone
echo "Set timezone"
timedatectl set-timezone Europe/Minsk
dnf install -y chrony
systemctl enable chronyd --now

#---Configuring the firewall
echo "Configuring the firewall"
firewall-cmd --permanent --add-port={80/tcp,443/tcp,10051/tcp,10050/tcp,10050/udp,10051/udp}
firewall-cmd --reload

#---SELinux
echo "Configuring SELinux"
setenforce 0
sed -i 's/^SELINUX=.*/SELINUX=disabled/g' /etc/selinux/config

#---Install mariadb server
echo "Install mariadb server"
dnf install -y mariadb-server
systemctl enable mariadb --now
mysql -u root -e "SET PASSWORD FOR root@'localhost' = PASSWORD('alena')"

#---Install Nginx
echo "Install Nginx"
dnf install -y nginx
systemctl enable nginx --now

#---Install PHP
echo "Install PHP"
dnf install -y php php-fpm php-mysqli
#configure /etc/php.ini
sed -i 's+;date.timezone =.*+date.timezone = "Europe/Minsk"+' /etc/php.ini
sed -i 's/max_execution_time =.*/max_execution_time = 300/' /etc/php.ini
sed -i 's/post_max_size =.*/post_max_size = 16M/' /etc/php.ini
sed -i 's/max_input_time =.*/max_input_time = 300/' /etc/php.ini
#run php-fpm
systemctl enable php-fpm --now

#---Configure file /etc/nginx/nginx.conf (for NGINX to process PHP)
echo "Configure file /etc/nginx/nginx.conf (for NGINX to process PHP)"
sed -i '50i\location ~ \.php$ {\nset $root_path /usr/share/nginx/html;\nfastcgi_pass unix:/run/php-fpm/www.sock;\nfastcgi_index index.php;\nfastcgi_param SCRIPT_FILENAME $root_path$fastcgi_script_name;\ninclude fastcgi_params;\nfastcgi_param DOCUMENT_ROOT $root_path;\n}' /etc/nginx/nginx.conf
nginx -t
systemctl restart nginx
echo "<?php phpinfo(); ?>" >> /usr/share/nginx/html/index.php

#---Install Zabbix
echo "Install Zabbix"
dnf install -y https://repo.zabbix.com/zabbix/5.0/rhel/8/x86_64/zabbix-release-5.0-1.el8.noarch.rpm
dnf install -y zabbix-server-mysql zabbix-web-mysql zabbix-get

#---Configuring DB
echo "Configuring DB"
mysql -uroot -palena <<EOF
CREATE DATABASE zabbix DEFAULT CHARACTER SET utf8 DEFAULT COLLATE utf8_bin;
GRANT ALL PRIVILEGES ON zabbix.* TO zabbix@localhost IDENTIFIED BY 'zabbix';
EOF
#to apply the scheme, go to the directory, unpack the archive and restore the database
echo "Unpack the archive and restore the database"
cd /usr/share/doc/zabbix-server-mysql
gunzip create.sql.gz
mysql -u root -palena zabbix < create.sql
#configure /etc/zabbix/zabbix_server.conf
echo "Configure /etc/zabbix/zabbix_server.conf"
sed -i 's/# DBPassword=.*/DBPassword=zabbix/' /etc/zabbix/zabbix_server.conf
sed -i 's/DBUser=.*/ DBUser=zabbix/' /etc/zabbix/zabbix_server.conf
sed -i 's/DBName=.*/ DBName=zabbix/' /etc/zabbix/zabbix_server.conf
sed -i 's/Timeout=.*/Timeout=10/' /etc/zabbix/zabbix_server.conf
chown apache:apache /etc/zabbix/web

#Run zabbix server
echo "Run zabbix server"
systemctl enable zabbix-server --now
sed -i 's+set $root_path /usr/share/nginx/html;+set $root_path /usr/share/zabbix;+' /etc/nginx/nginx.conf
sed -i '42s+root.*+root /usr/share/zabbix;+' /etc/nginx/nginx.conf
systemctl restart nginx
