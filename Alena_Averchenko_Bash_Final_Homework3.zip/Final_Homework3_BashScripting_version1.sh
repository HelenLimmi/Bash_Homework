#!/bin/bash
#create new file with parse lines
awk -F'"' -v OFS='' '{ for (i=2; i<=NF; i+=2) gsub(",", "", $i) } 1' accounts.csv | 
#add new column userid
awk -F, -v d="userid" -F"," 'FNR==1{a="userid"} FNR>1{a=d} {print $1","$2","$3","$4","$5","a","$6","$7","$8}' |
while IFS=, read -r col1 col2 col3 col4 col5 col6 col7 col8 col9
do
  if [[ "$col1" != "id" ]]; then
    firstLetter=${col5:0:1}
    surname=$(echo $col5 | cut -d' ' -f2)
    col6=${firstLetter,}${surname,,}
  fi
echo "${col1},${col2},${col3},${col4},${col5},${col6},${col7},${col8},${col9}"
done |
awk -F, '{d=dup[$6]++; userid=$6; if ($1!="id") res=gsub(userid,(userid (d+1)),$userid); echo userid} 1' > accounts_new.csv
