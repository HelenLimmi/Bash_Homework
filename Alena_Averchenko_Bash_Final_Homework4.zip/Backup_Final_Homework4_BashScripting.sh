#!/bin/bash
FILE=/etc/cron.daily/EveryDayBackupHomeDirectory.backup
if ! [ -f $FILE ] ; then
  cat << 'EOF' > $FILE
  #!/bin/bash
  . /home/devops/Bash/config
  CurrentDate=\$(date '+%d-%m-%y-%H%M%S')
  tar -zcvf "\$CurrentDate.tar.gz" /home/*/.* /root
  mv "\$CurrentDate.tar.gz" \$ClientShareDirectory
  EOF
  chmod +x $FILE
else
  echo "The script for the backup has been created."
fi