#!/bin/bash
. config
#---For server---
if [ "$1" = "server" ] ; then
  #---Install nfs-utils and run services
  echo " Install nfs-utils"
  dnf install -y nfs-utils
  systemctl start nfs-server.service
  systemctl enable nfs-server.service

  #---Create directory for sharing on an NFS server.
  echo " Create directory for sharing on an NFS server."
  mkdir -p $ServerShareDirectory
  chmod o+w $ServerShareDirectory

  #---Add an entry to the NFS server configuration file
  echo "$ServerShareDirectory $ServerIpAdress/24($RW,$SYNC,$NOALL_SQUASH,$ROOT_SQUASH)" >> /etc/exports

  #---Export file system
  echo " Export file system"
  sleep 3 # to view information output
  exportfs -arv
  echo " Current export list"
  sleep 3 # to view information output
  exportfs -s

  #---Configuring firewall
  echo " Configuring firewall"
  firewall-cmd --permanent --add-service=nfs
  firewall-cmd --permanent --add-service=rpc-bind
  firewall-cmd --permanent --add-service=mountd
  firewall-cmd --reload

#---For client---
elif [ "$1" = "client" ] ; then
  #---Install nfs-utils nfs4-acl-tools and run services
  echo " Install nfs-utils"
  dnf install -y nfs-utils nfs4-acl-tools
  #check mount information for NFS server
  echo "Check mount information"
  showmount -e $ServerIpAdress

  #---Create a directory, mount it as an nfs filesystem:
  echo " Create a directory"
  mkdir -p $ClientShareDirectory
  echo " Mount it as an nfs filesystem"
  sleep 3 # to view information output
  mount -t nfs $ServerIpAdress:$ServerShareDirectory $ClientShareDirectory
  #check the remote filesystem has been mounted
  mount | grep nfs

  #---Make mount permanent after system reboot
  echo "$ServerIpAdress:$ServerShareDirectory $ClientShareDirectory nfs defaults 0 0" >> /etc/fstab
fi
