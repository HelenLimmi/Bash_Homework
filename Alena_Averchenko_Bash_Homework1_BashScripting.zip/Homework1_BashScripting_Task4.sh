#!/bin/bash

echo "Home dir: $HOME"
echo "User Name: $(whoami)"
echo "User ID: $UID($(whoami))"
echo "Group Information: $(id -g $(whoami))($(whoami))"
echo "Terminal: $TERM"
echo "Current directory: $PWD"
echo "System date/time: $(date)"

