#!/bin/bash
function InfoFileDir() {
  path=$1
  for file in *
  do
    Path=$(realpath $file) #path for file or directory
    NPerm=$(stat -c%a $file) #permission in octal form
    LPerm=$(stat -c%A $file) #permission like ‘rwx’
    Type=$(stat -c%F $file) #file type (regular file or directory)
    echo -e "File: '$Path'\nType: $Type\nPermissions: (0$NPerm/$LPerm)\n------"
  done
}
InfoFileDir $1

