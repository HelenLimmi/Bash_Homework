#!/bin/bash
function HomeDirectory() {
  usr=$1
  #print home directory of the user
  eval echo "~$usr"
}
HomeDirectory $1
