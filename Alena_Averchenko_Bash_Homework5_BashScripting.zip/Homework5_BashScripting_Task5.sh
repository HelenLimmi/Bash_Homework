#!/bin/bash
function MinMaxValue() {
  max=0
  min=0
  arr=("$@")
  for i in "${arr[@]}";
  do
    #choose min and max number
    if [ $i -gt $max ] ; then 
      max=$i
    fi
    if [[ $i -lt $min || $min -eq 0 ]] ; then
      min=$i
    fi
  done
}
MinMaxValue "$@"
echo -e "Min: $min\nMax: $max"

