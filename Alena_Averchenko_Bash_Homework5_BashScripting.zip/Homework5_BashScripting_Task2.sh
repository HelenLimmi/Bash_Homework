#!/bin/bash
function Party() {
  years=$1
  letter=$2
  # check the number of years
  if [ $years -ge 18 ] ; then
    echo "You may go to the party."
  else 
    # check if you have a letter
    if [ "$letter" = "yes" ] ; then
      echo "You may go but must be back before midnight."
    else
      echo "You cannot go to the party."
    fi
  fi
}
Party $1 $2

