#!/bin/bash
function SumProdNum() {
  prod=1
  arr=("$@")
  for i in "${arr[@]}";
  do
    sum=$((i + sum)) #get sum of the number
    prod=$((i * prod)) #get product of the number
  done
}
SumProdNum "$@"
echo -e "Sum: $sum\nProd: $prod"

