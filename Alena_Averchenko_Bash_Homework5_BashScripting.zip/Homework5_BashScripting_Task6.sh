#!/bin/bash
function BackgroundSleep {
  #check if command ran in background
  if ! ps -ef | grep -q "[s]leep 1000" ; then
    sleep 1000 &
  fi
}
BackgroundSleep

