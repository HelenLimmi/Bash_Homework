#!/bin/bash
function NameAndPath {
  PathScript=$(realpath $0) #get full path of the name script
  NameScript=$(basename $0) #get script name
  echo -e "$PathScript\n$NameScript"
}
NameAndPath

