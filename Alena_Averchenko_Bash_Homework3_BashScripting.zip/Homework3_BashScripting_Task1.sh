#!/bin/bash
leanYearMonths=(31 28 31 30 31 30 31 31 30 31 30 31)
currentMonth=$(date +"%m") #current month (as a number)
echo ${leanYearMonths[$currentMonth+1]}