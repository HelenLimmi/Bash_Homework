#!/bin/bash
if ps -ef | grep -q [h]ttpd ; then 
    echo "This machine is running a web server."
else 
    echo "This machine is not running a web server."
fi