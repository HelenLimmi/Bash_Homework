#!/bin/bash
function rand() {
    echo $(($RANDOM % ${1}))
}
max=0
min=0
for item in `seq 1 10`
    do
	#get random value
        value="$(rand 100)"
        echo "[$item] => ${value}"
	#get sum of all values
        sum=$(($sum + $value))
	#choose min and max number
        if [ $value -gt $max ] ; then 
            max=$value
        fi
        if [[ $value -lt $min || $min -eq 0 ]] ; then
            min=$value
        fi
    done
    
echo "max=$max"
echo "min=$min"
echo "sum=$sum"
