#!/bin/bash
Command=$(cat /etc/shadow 2> /dev/null)
ExitStatus=$?
#check exit status of the command and report message
if [ $ExitStatus -eq 0 ] ; then
    echo "Command succeeded"
    exit $ExitStatus
else 
    echo "Command failed"
    exit $ExitStatus
fi